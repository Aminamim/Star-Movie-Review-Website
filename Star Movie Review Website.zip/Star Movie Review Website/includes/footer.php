
<hr>
<footer>
	<p class="text-center"><a href="index.php">&copy; STAR <?php echo date("Y"); ?></a></p>
</footer>

<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
</body>
</html>
