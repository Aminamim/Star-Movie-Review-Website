<?php
	require_once('includes/database.php');
	require_once('includes/header.php');

	session_start();

	$movie_id = $_GET['id'];
	$user_id = $session_id;

	$my_qur = "SELECT * FROM favs WHERE movie_id = '$movie_id' AND user_id = '$user_id'";
	$qur_run = $conn->query($my_qur);
	if(mysqli_num_rows($qur_run)>0){
		header("Location: useraccount.php");
	}
	else{
		$query_str = "INSERT INTO favs VALUES('$movie_id','$user_id')";
		$conn->query($query_str);
		header("Location: useraccount.php");
	}
	


?>